/**************************************************************
 * Dummy Header for Unix to Windows NT portability
 * Created for NTP package
 **************************************************************/
